fail2ban.client.configurator module
===================================

.. automodule:: fail2ban.client.configurator
    :members:
    :undoc-members:
    :show-inheritance:
