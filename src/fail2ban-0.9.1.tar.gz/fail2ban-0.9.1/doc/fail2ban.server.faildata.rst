fail2ban.server.faildata module
===============================

.. automodule:: fail2ban.server.faildata
    :members:
    :undoc-members:
    :show-inheritance:
