fail2ban.protocol module
========================

.. automodule:: fail2ban.protocol
    :members:
    :undoc-members:
    :show-inheritance:
